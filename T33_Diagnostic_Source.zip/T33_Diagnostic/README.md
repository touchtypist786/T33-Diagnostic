# T33 Diagnostic (Android 13)

A minimal diagnostic Android project. It asks an Accessibility Service to observe hardware **key events** using `FLAG_REQUEST_FILTER_KEY_EVENTS`, records key code, scan code, device ID, source, action, repeat count and press duration, and passes all events through unchanged.

## Important limitations

- This is source code, not a prebuilt APK. It must be built with Android Studio or the included GitHub Actions workflow.
- Android's AccessibilityService key filter only receives key events the system routes through that API. It does not guarantee capture of Bluetooth mouse-wheel, generic motion, vendor-specific camera-remote or every media event.
- The service deliberately returns `false` and does not consume or remap events. This is a diagnostic build, not the finished Zikr counter.
- Screen-off reception is not established by this test. A successful foreground test does not prove that Android/Samsung will deliver the same event while locked or asleep.
- Accessibility permission is powerful. Enable this service only for this test, and disable it afterwards if you do not continue using the diagnostic app.

## Build APK using GitHub Actions

1. Create a GitHub repository and upload the contents of this folder (not the folder itself).
2. Open the repository's **Actions** tab.
3. Select **Build diagnostic APK** and press **Run workflow** (or push to `main`).
4. Open the completed workflow run and download the `T33-Diagnostic-debug-apk` artifact.
5. Extract the downloaded ZIP; it contains `app-debug.apk`.
6. Transfer the APK to the Android phone and install it. Android may ask permission to install from that source.

## Test on phone

1. Open T33 Diagnostic and tap **Open Accessibility Settings**.
2. Enable **T33 button event detector**.
3. Return to the app.
4. Press each ring button once, then try a longer press on the middle button.
5. Tap **Refresh event log** and send a screenshot or copy of the log.

If the log remains empty while the T33 still changes camera settings or tabs, this particular Android key-event interception route is not receiving the T33 signals. Do not infer that the ring is broken.
