package com.example.t33diagnostic

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class T33KeyService : AccessibilityService() {
    private val downTimes = mutableMapOf<Int, Long>()
    private val formatter = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = serviceInfo.apply {
            flags = flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        }
        append("Service connected. Waiting for hardware key events…")
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val now = System.currentTimeMillis()
        val action = when (event.action) {
            KeyEvent.ACTION_DOWN -> "DOWN"
            KeyEvent.ACTION_UP -> "UP"
            else -> "ACTION_${event.action}"
        }
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) downTimes[event.keyCode] = event.eventTime
        val duration = if (event.action == KeyEvent.ACTION_UP) {
            val start = downTimes.remove(event.keyCode)
            if (start != null) "${event.eventTime - start} ms" else "unknown"
        } else "—"
        val source = "0x${event.source.toString(16)}"
        val line = "${formatter.format(Date(now))} | $action | ${KeyEvent.keyCodeToString(event.keyCode)} (${event.keyCode}) | scan=${event.scanCode} | device=${event.deviceId} | source=$source | repeat=${event.repeatCount} | hold=$duration"
        append(line)
        // Diagnostic only: let Android and the foreground app receive the original event.
        return false
    }

    private fun append(line: String) {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val old = prefs.getString(LOG_KEY, "") ?: ""
        val updated = (old.lines().filter { it.isNotBlank() } + line).takeLast(100).joinToString("\n")
        prefs.edit().putString(LOG_KEY, updated).apply()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    companion object {
        const val PREFS = "t33_diagnostic"
        const val LOG_KEY = "event_log"
    }
}
