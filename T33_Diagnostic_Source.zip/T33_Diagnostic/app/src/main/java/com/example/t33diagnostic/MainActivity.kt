package com.example.t33diagnostic

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var logView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
        }
        val title = TextView(this).apply {
            text = "T33 Button Diagnostic"
            textSize = 24f
            setTextColor(0xFF202124.toInt())
        }
        val intro = TextView(this).apply {
            text = "This test only records key events Android exposes to an Accessibility Service. It does not change button behaviour or count Zikr yet."
            textSize = 15f
            setPadding(0, 12, 0, 16)
        }
        val settings = Button(this).apply {
            text = "Open Accessibility Settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val refresh = Button(this).apply {
            text = "Refresh event log"
            setOnClickListener { refreshLog() }
        }
        val clear = Button(this).apply {
            text = "Clear event log"
            setOnClickListener {
                getSharedPreferences(T33KeyService.PREFS, MODE_PRIVATE).edit().remove(T33KeyService.LOG_KEY).apply()
                refreshLog()
            }
        }
        logView = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFF202124.toInt())
            text = "No events recorded yet. Enable the service, return here, then press each T33 button once."
            setPadding(12, 12, 12, 12)
        }
        val scroll = ScrollView(this).apply { addView(logView) }
        root.addView(title)
        root.addView(intro)
        root.addView(settings, matchWrap())
        root.addView(refresh, matchWrap())
        root.addView(clear, matchWrap())
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (::logView.isInitialized) refreshLog()
    }

    private fun refreshLog() {
        val prefs = getSharedPreferences(T33KeyService.PREFS, MODE_PRIVATE)
        val entries = prefs.getString(T33KeyService.LOG_KEY, "") ?: ""
        logView.text = if (entries.isBlank()) "No key events recorded.\n\nIf pressing the ring still changes tabs or camera settings but nothing appears here, Android may be routing those signals as mouse/media events that this key-event filter cannot observe." else entries
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 }
}
