plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.t33diagnostic"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.t33diagnostic"
        minSdk = 26
        targetSdk = 33
        versionCode = 1
        versionName = "0.1-diagnostic"
    }
}
